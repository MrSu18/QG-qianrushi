
//**************************************
//�ֿ�
extern uchar code Y_X_M[];
extern uchar code test[];
extern uchar code new[];
extern uchar code list[];
extern uchar code old[];
extern uchar code choose[];
extern uchar code clear[];
extern uchar code huafenxian[];
extern uchar code huafenhenxian[];
extern uchar code enemy[];
extern uchar code zhansunenemy[];
extern uchar code placed[];
extern uchar code tower[];
extern uchar code home[];
extern uchar code enemyhome[];
extern uchar code qian[];
extern uchar code diren[];
extern uchar code shuzi[];
extern uchar code zifu[];
extern uchar code shibai[];
extern uchar code chengong[];
extern uchar code paihan[];
extern uchar code xuanguan[];
extern uchar code daojulang[];

//********************************
