#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include<string.h>
#include "LinkStack.h"

int main()
{
    LinkStack s;
    LinkStack q;
    initLStack(&s);
    initLStack(&q);
    char c,data[100];
    printf("��������׺����ʽ��ֻ�ܽ�����������:");
    scanf("%c",&c);
    printf("��׺����ʽΪ��");
    Infixtosuffix(&s,c,data);//���׺����ʽ


    //���п�ʼ��׺����ʽ�ļ���
    int i=0;
    char str[100];
    elemType n1,n2;
    int n=0;
    for(i = 0; data[i] != '\0'; i++)
    {
        while(isdigit(data[i]))
        {
            str[n++] = data[i++];
            str[n] = '\0';
            if(n >= 100)
            {
                printf("����ĵ������ݹ���\n");
                system("pause");
                return -1;
            }
            if(data[i] == ' ')
            {
                n1 = atoi(str);
                push(&q, n1);
                n = 0;
                break;
            }
        }
        switch(data[i])
        {
            case '+':
            {
                pop(&q, &n1);
                pop(&q, &n2);
                push(&q, n1 + n2);
                break;
            }
            case '-':
            {
                pop(&q, &n1);
                pop(&q, &n2);
                push(&q, n2 - n1);
                break;
            }
            case '*':
            {
                pop(&q, &n1);
                pop(&q, &n2);
                push(&q, n1 * n2);
                break;
            }
            case '/':
            {
                pop(&q, &n1);
                pop(&q, &n2);
                if(n1 != 0)
                push(&q, n2 / n1);
                else
                {
                    printf("\n������󣺳�������Ϊ��\n");
                    system("pause");
                    return -1;
                }
                break;
            }
        }

    }
    pop(&q, &n1);
    printf("\n������Ϊ��%d\n\n", n1);

    system("pause");

    return 0;
}
