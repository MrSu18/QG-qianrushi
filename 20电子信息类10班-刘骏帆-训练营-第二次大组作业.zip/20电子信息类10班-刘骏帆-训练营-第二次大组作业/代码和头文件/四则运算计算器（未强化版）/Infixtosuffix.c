#include <stdio.h>
#include<stdlib.h>
#include <ctype.h>
#include<string.h>
#include "LinkStack.h"

void Infixtosuffix(LinkStack*s,ElemType c,ElemType a[100])
{

	int i=0;
	char e,last;
	while(c!='\n')
	{
		while(c>='0'&&c<='9')
		{
			a[i]=c;i++;
			printf("%c",c);
			scanf("%c",&c);

			if(c<'0'||c>'9')
			{
				a[i]=' ';i++;
				printf(" ");
			}
		}
		if(c=='+'||c=='-')
		{
			if(s->count==0)
			{
				pushLStack(s,c);
			}
			else
			{
				do
				{
					popLStack(s,&e);
					if(e=='(')
					{
						pushLStack(s,e);
					}
					else
					{
						a[i]=e;i++;
						printf("%c",e);
					}
				}while (e!='('&&s->count!=0);
				pushLStack(s,c);
			}
		}
		else if(c=='*'||c=='/'||c=='(')
		{
			pushLStack(s,c);
		}
		else if(c==')')
		{
			popLStack(s,&e);
			while(e!='(')
			{
				a[i]=e;i++;
				printf("%c",e);
				popLStack(s,&e);
			}
		}
		else if(c=='\n')
		{
			break;
		}
		else
		{
			printf("������������������롣");
			return ERROR;
		}
		scanf("%c",&c);
	}
	while (s->count!=0)
	{
		popLStack(s,&last);
		a[i]=last;i++;
		printf("%c",last);
	}
	a[i]='\n';
	a[i+1]='\0';
	//printf("\n");
	//puts(a);

}
