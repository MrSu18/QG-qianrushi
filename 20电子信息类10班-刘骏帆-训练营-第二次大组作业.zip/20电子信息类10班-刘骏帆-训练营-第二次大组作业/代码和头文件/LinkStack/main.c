#include <stdio.h>
#include "../../head/LinkStack.h"
int main()
{
	LinkStack*stack;
	LinkStack*e;
	jiemian();
	menu(stack,e);
	return 0;
}
